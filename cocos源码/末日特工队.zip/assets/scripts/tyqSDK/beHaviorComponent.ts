import { assetManager, Component, SpriteFrame, Texture2D, _decorator, Node, Sprite } from "cc";
import { Wechat } from "./platform/wechat/wechat";
import { Channel, tyqAdManager } from "./tyqAdManager";
import { tyqSDKConfig } from "./tyqSDKConfig";
const { ccclass, property } = _decorator;

@ccclass('beHaviorComponent')
export class beHaviorComponent extends Component {

    @property({ type: Node }) icon: Node = null;
    @property({ tooltip: "广告业务1：系统分配，0：自定义" }) strategy = 1;
    @property({ tooltip: "强制0：广告，1分享，strategy == 1时才生效" }) currentShow = 0;

    private isClick = false
    onEnable() {
    }

    start() {
        if (!tyqSDKConfig.isOpenBeHavior) {
            console.log("beHaviorComponent destroy")
            this.destroy()
            return
        }

        this.node.on(Node.EventType.TOUCH_START, () => {
            console.log("beHaviorComponent 点击")
            this.isClick = true
        }, this);
        if (tyqAdManager.getChannel() != Channel.WECHAT) {
            return
        }
        if (this.strategy == 1) {
            if (Wechat.isShareBehavior()) {
                this.loadAsset("icon", "prop/ui_Share", SpriteFrame, null, (err, sp) => {
                    this.icon.getComponent(Sprite).spriteFrame = sp
                })
                tyqAdManager.reportShareBehavior(1, this.strategy, 1)
            } else {
                tyqAdManager.reportShareBehavior(1, this.strategy, 0)
            }
        } else {
            if (this.currentShow == 1) {
                this.loadAsset("icon", "prop/ui_Share", SpriteFrame, null, (err, sp) => {
                    this.icon.getComponent(Sprite).spriteFrame = sp
                })
                tyqAdManager.reportShareBehavior(1, this.strategy, 1)
            } else {
                tyqAdManager.reportShareBehavior(1, this.strategy, 0)

            }
        }

    }

    onDisable() {
        if (tyqAdManager.getChannel() != Channel.WECHAT) {
            return
        }
        if (this.strategy == 1) {
            if (Wechat.isShareBehavior()) {
                this.loadAsset("icon", "prop/ui_Share", SpriteFrame, null, (err, sp) => {
                    this.icon.getComponent(Sprite).spriteFrame = sp
                })
                tyqAdManager.reportShareBehavior(this.isClick ? 4 : 3, this.strategy, 1)
            } else {
                tyqAdManager.reportShareBehavior(this.isClick ? 4 : 3, this.strategy, 0)
            }
        } else {
            if (this.currentShow == 1) {
                this.loadAsset("icon", "prop/ui_Share", SpriteFrame, null, (err, sp) => {
                    this.icon.getComponent(Sprite).spriteFrame = sp
                })
                tyqAdManager.reportShareBehavior(this.isClick ? 4 : 3, this.strategy, 1)
            } else {
                tyqAdManager.reportShareBehavior(this.isClick ? 4 : 3, this.strategy, 0)
            }
        }

    }

    /**
   * 从bundle中加载某个资源，优先使用缓存中的
   * @param bundleName bundle名称
   * @param path 资源路径
   * @param assetType 资源类型
   * @param onProgress 加载进度回调
   * @param onComplete 加载完成回调
   */
    loadAsset(bundleName: string, path: string, assetType: any, onProgress?: Function, onComplete?: Function) {
        if (assetType == SpriteFrame) {
            path += "/spriteFrame";
        } else if (assetType == Texture2D) {
            path += "/texture";
        }
        let bundle = assetManager.getBundle(bundleName);
        if (bundle && bundle.get(path, assetType)) {
            if (onComplete) {
                onComplete(null, bundle.get(path, assetType));
            }
            return;
        }

        let loadAssetFunc = () => {
            bundle.load(path, assetType, (finish: number, total: number) => {
                if (onProgress) {
                    onProgress(finish / total);
                }
            }, (err, asset) => {
                if (err) {
                    console.log("ResManager.loadAsset error:" + err.message, "bundleName:" + bundleName, "path:" + path, err);
                    if (onComplete) {
                        onComplete(err);
                    }
                    return;
                }
                if (onComplete) {
                    onComplete(null, asset);
                }
            });
        };

        if (!bundle) {
            assetManager.loadBundle(bundleName, (err, retBundle) => {
                if (err) {
                    if (onComplete) {
                        onComplete(err);
                    }
                    return;
                }
                bundle = retBundle;
                loadAssetFunc();
            });
            return;
        }

        loadAssetFunc();
    }

}