
export default class Http {
	public xhr: XMLHttpRequest = null!;
	/**
	 * 单例
	 */
	private static _instance: Http;

	public static getInstance(): Http {
		if (!this._instance) {
			this._instance = new Http();
		}
		return this._instance;
	}

	/**
	 * post请求
	 * @param {string} url
	 * @param {object} params
	 * @param {function} callback
	 */
	httpPost(url: string, params: any, callback: Function, failCb?: Function) {
		// cc.myGame.gameUi.onShowLockScreen();
		let xhr = new XMLHttpRequest();
		xhr.onreadystatechange = function () {
			// cc.log('xhr.readyState=' + xhr.readyState + '  xhr.status=' + xhr.status);
			if (xhr.readyState === 4 && (xhr.status >= 200 && xhr.status < 300)) {
				let respone = xhr.responseText;
				let rsp = JSON.parse(respone);
				// cc.myGame.gameUi.onHideLockScreen();
				callback(rsp);
			} else {
				callback(-1);
			}
		};
		xhr.open('POST', url, true);
		// if (cc.sys.isNative) {
		// xhr.setRequestHeader('Access-Control-Allow-Origin', '*');
		// xhr.setRequestHeader('Access-Control-Allow-Methods', 'GET, POST');
		// xhr.setRequestHeader('Access-Control-Allow-Headers', 'x-requested-with,content-type');
		// xhr.setRequestHeader("Content-Type", "application/json");
		// xhr.setRequestHeader('Authorization', 'Bearer ' + cc.myGame.gameManager.getToken());
		// }

		// note: In Internet Explorer, the timeout property may be set only after calling the open()
		// method and before calling the send() method.
		xhr.timeout = 8000;// 8 seconds for timeout
		xhr.send(JSON.stringify(params));

		xhr.onerror = (err) => {
			console.log(err);
			if (failCb) {
				failCb(err);
			}
		};

	}

}
